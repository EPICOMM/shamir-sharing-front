const swup = new Swup({});

options = {
    "outerStyle": "disable",
    "hoverItemMove": false,
    "defaultCursor": false,
    "outerWidth": 15,
    "outerHeight": 15,
};

magicMouse(options);
